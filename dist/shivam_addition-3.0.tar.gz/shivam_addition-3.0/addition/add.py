#!/usr/bin/env python
from __future__ import unicode_literals
# -*- coding: UTF-8 -*-

"""
Author: Shivam Gupta
Description:
"""

def add(x, y):
    """
    Add two numbers
    """
    return x + y
